"""View for the e_donations project."""
